﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Generic_DB_Reflection
{
    class Program
    {
        static string conn_string = string.Empty;

        static void Main(string[] args)
        {
            StringBuilder path = new StringBuilder();
            path.Append(Directory.GetParent(Directory.GetParent(Environment.CurrentDirectory).ToString()).ToString());
            path.Append(@"\DB\Demo_DB.mdf");

            conn_string = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=" + path + ";Integrated Security=True";

            //
            // ONE PARAMETER TEST : USER WITH PARAMETER -- @USER_ID
            // 

            // CREATE USER
            User user_a = new User();
            user_a.User_Id = 1;

            // PRINT BEFORE FOR TEST
            Console.Write(PrintBefore<User>(user_a));

            // START - TIME THE PROCESS
            DateTime start = new DateTime();
            DateTime end = new DateTime();
            start = DateTime.Now;

            // $$$ MONEY CALL $$$ 
            user_a = GetData<User>(user_a, "Inquire_User");

            // STOP - TIME THE PROCESS
            end = DateTime.Now;

            // PRINT AFTER FOR TEST 
            Console.Write(PrintAfter<User>(user_a));

            // PRINT TIMING RESULTS 
            TimeSpan process_time = end - start;
            Console.WriteLine($"Processing time: {process_time}");

            // 
            // MULTI-PARAMETER TEST : STUDENT WITH TWO PARAMETERS -- @STUDENT_ID , @FIRST_NAME
            //
            Console.WriteLine("-----------------------------------------------------");

            // CREATE STUDENT
            Student student_a = new Student();
            student_a.Student_Id = 1;
            student_a.First_Name = "Douglas";

            // PRINT BEFORE FOR TEST
            Console.Write(PrintBefore<Student>(student_a));

            // START - TIME THE PROCESS
            start = DateTime.Now;

            // $$$ MONEY CALL $$$
            student_a = GetData<Student>(student_a, "Inquire_Student");

            // STOP - TIME THE PROCESS
            end = DateTime.Now;

            // PRINT AFTER FOR TEST 
            Console.Write(PrintAfter<Student>(student_a));

            // PRINT TIMING RESULTS 
            process_time = end - start;
            Console.WriteLine($"Processing time: {process_time}");
        }

        static string PrintObj<T>(T obj)
        {
            Type obj_type = obj.GetType();
            PropertyInfo[] obj_properties = obj_type.GetProperties();
            StringBuilder return_sb = new StringBuilder();

            foreach (PropertyInfo pi in obj_properties)
            {
                return_sb.AppendFormat("{0,-10} - {1,-20}\n", pi.Name, pi.GetValue(obj, null));
                //return_sb.AppendLine($"{pi.Name}: {pi.GetValue(obj, null)}");
            }

            return return_sb.ToString();
        }

        static string PrintBefore<T>(T obj)
        {
            StringBuilder return_sb = new StringBuilder("\tBEFORE\n");

            return_sb.AppendLine(PrintObj<T>(obj));
            
            return return_sb.ToString();
        }

        static string PrintAfter<T>(T obj)
        {
            StringBuilder return_sb = new StringBuilder("\tAFTER\n");

            // IF OBJ INFO IS FOUND IN DB, PRINT USER INFO... ELSE PRINT ERROR
            if (obj != null)
            {
                return_sb.AppendLine(PrintObj<T>(obj));
            }
            else
                return_sb.AppendLine("Object passed was not found in database.");

            return return_sb.ToString();
        }

        static T GetData<T>(T obj, string ProcedureName)
        {
            string proc_id = null;
            string parameter = null;
            T return_obj = default(T);
            string command_string = null;

            // TODO: IMPLEMENT TRY CATCHES WHEN CALLING TO DB
            using (SqlConnection cn = new SqlConnection(conn_string))
            {
                // COMMAND 1 - GET OBJECT_ID FOR THE PROCEDURE PASSED
                // TODO: FIX SQL TO AVOID SQL INJECTION
                command_string = $"SELECT OBJECT_ID FROM SYS.PROCEDURES WHERE NAME = '{ProcedureName}';";
                SqlCommand comm_1 = new SqlCommand(command_string, cn);
                comm_1.CommandType = CommandType.Text;

                cn.Open();
                SqlDataReader reader = comm_1.ExecuteReader();

                if (reader.Read())
                {
                    IDataRecord record = (IDataRecord)reader;
                    proc_id = record.GetValue(0).ToString();    // SHOULD ONLY RETURN ONE VALUE 
                }
                else
                {
                    Console.WriteLine($"{ProcedureName} not found.");
                    return default(T);
                }
                reader.Close();

                // COMMAND 2 - GET ALL PARAMETERS FOR THE PROCEDURE USING THE OBJECT_ID FOUND IN COMMAND 1
                command_string = "SELECT * FROM SYS.PARAMETERS WHERE OBJECT_ID = " + proc_id;
                SqlCommand comm_2 = new SqlCommand(command_string, cn);

                reader = comm_2.ExecuteReader();
                // TODO: CHANGE FROM IF TO WHILE AND GRAB ALL PARAMETERS IN PROCEDURE
                LinkedList<string> parameter_list = new LinkedList<string>();
                while (reader.Read())
                {
                    IDataRecord record = (IDataRecord)reader;
                    parameter = record.GetValue(1).ToString(); // GRABS NAME VALUE -- FIELD 1 IS NAME
                    parameter_list.AddLast(parameter);
                }
                reader.Close();
                // NO ERROR IF THERE IS NO PARAMETERS

                // COMMAND 3 - EXECUTE PROCEDURE   
                using (SqlCommand comm_3 = new SqlCommand(ProcedureName, cn))
                {
                    comm_3.CommandType = CommandType.StoredProcedure;

                    Type obj_type = obj.GetType();
                    PropertyInfo[] obj_properties = obj_type.GetProperties();

                    foreach (string p in parameter_list)
                    {
                        string property_name = null;
                        object property_value = null;
                        string param_name = p.Remove(0, 1);  // REMOVE @ SYMBOL FROM PARAM NAME

                        for (int i = 0; i < obj_properties.Length; i++)
                        {
                            if (param_name.Equals(obj_properties[i].Name.ToString()))
                            {
                                property_name = obj_properties[i].Name.ToString();
                                property_value = obj.GetType().GetProperty(property_name).GetValue(obj);
                                i += obj_properties.Length; // BREAK OUT OF FOR LOOP IF FOUND 
                            }
                        }
                        SqlParameter param = new SqlParameter(param_name, property_value);
                        comm_3.Parameters.Add(param);
                    }

                    reader = comm_3.ExecuteReader();
                    if (reader.Read())
                    {
                        // GENERICALLY CREAT OBJECT
                        return_obj = (T)Activator.CreateInstance(obj_type);

                        // MATCH UP DB FIELDS WITH OBJECT PROPERTIES AND SET VALUE IN RETURN OBJECT
                        IDataRecord record = (IDataRecord)reader;
                        for (int i = 0; i < record.FieldCount; i++)
                        {
                            string field_name = record.GetName(i).ToString();
                            var field_value = record.GetValue(i);
                            string prop_name = obj.GetType().GetProperty(record.GetName(i)).Name;
                            Type prop_type = obj.GetType().GetProperty(record.GetName(i)).Name.GetType();

                            obj_type.GetProperty(prop_name).SetValue(return_obj, field_value, null);
                        }
                    }
                }
            }

            // RETURN NULL: RECORD NOT FOUND IN DB
            // RETURN OBJECT: PASSED OBJ TYPE POPULATED WITH RESULTS FROM DB
            return return_obj;
        }
    }
}