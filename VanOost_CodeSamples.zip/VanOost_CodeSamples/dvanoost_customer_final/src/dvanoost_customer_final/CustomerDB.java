package dvanoost_customer_final;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

public class CustomerDB {
	public static String ConnectionString = String.format(
			"jdbc:ucanaccess://%s\\database\\CUB001_CUSTOMER_MASTER.accdb;memory=true;",
			System.getProperty("user.dir"));

	// CREATE
	// --------------------------------------------------------------------------------------------
	public static Customer Create(ResultSet rs) {
		Customer customer = new Customer();

		try {
			customer.setCUST_ID(rs.getLong("CUST_ID"));
			customer.setCUST_FIRST_NM(rs.getString("CUST_FIRST_NM"));
			customer.setCUST_LAST_NM(rs.getString("CUST_LAST_NM"));
			customer.setCUST_ADDR_TXT(rs.getString("CUST_ADDR_TXT"));
			customer.setCUST_CITY_NM(rs.getString("CUST_CITY_NM"));
			customer.setCUST_ST_CD(rs.getString("CUST_ST_CD"));
			customer.setCUST_ZIP_CD(rs.getString("CUST_ZIP_CD"));
			customer.setCUST_EMAIL(rs.getString("CUST_EMAIL"));
			customer.setCUST_PHONE(rs.getString("CUST_PHONE"));
			customer.setCUST_USERNM(rs.getString("CUST_USERNM"));
			customer.setCUST_PASSWORD(rs.getString("CUST_PASSWORD"));
			customer.setCUST_ADD_USER_ID(rs.getLong("CUST_ADD_USER_ID"));
			customer.setCUST_ADD_DTM(rs.getTimestamp("CUST_ADD_DTM"));
			customer.setCUST_CHG_USER_ID(rs.getLong("CUST_CHG_USER_ID"));
			customer.setCUST_CHG_DTM(rs.getTimestamp("CUST_CHG_DTM"));
			customer.setCUST_STAT_CD(rs.getString("CUST_STAT_CD").charAt(0));
		} catch (SQLException e) {
			e.printStackTrace();
			customer = null;
		}

		return customer;
	}

	// UPDATE
	// --------------------------------------------------------------------------------------------
	public static void Update(Customer customer) {
		Connection cn = null;
		PreparedStatement ps = null;

		StringBuilder strSQL = new StringBuilder("UPDATE CUT001_CUSTOMER_MSTR ");
		strSQL.append("SET ");
		strSQL.append("CUST_FIRST_NM = ?, "); // 1
		strSQL.append("CUST_LAST_NM = ?, "); // 2
		strSQL.append("CUST_ADDR_TXT = ?, "); // 3
		strSQL.append("CUST_CITY_NM = ?, "); // 4
		strSQL.append("CUST_ST_CD = ?, "); // 5
		strSQL.append("CUST_ZIP_CD = ?, "); // 6
		strSQL.append("CUST_EMAIL = ?, "); // 7
		strSQL.append("CUST_PHONE = ?, "); // 8
		strSQL.append("CUST_USERNM = ?, "); // 9
		strSQL.append("CUST_PASSWORD = ?, "); // 10
		strSQL.append("CUST_CHG_USER_ID = ?, ");// 11
		strSQL.append("CUST_CHG_DTM = ? "); // 12
		strSQL.append("WHERE CUST_ID = ?;"); // 13

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());

			ps.setString(1, customer.getCUST_FIRST_NM());
			ps.setString(2, customer.getCUST_LAST_NM());
			ps.setString(3, customer.getCUST_ADDR_TXT());
			ps.setString(4, customer.getCUST_CITY_NM());
			ps.setString(5, customer.getCUST_ST_CD());
			ps.setString(6, customer.getCUST_ZIP_CD());
			ps.setString(7, customer.getCUST_EMAIL());
			ps.setString(8, customer.getCUST_PHONE());
			ps.setString(9, customer.getCUST_USERNM());
			ps.setString(10, customer.getCUST_PASSWORD());
			ps.setLong(11, customer.getCUST_CHG_USER_ID());

			java.util.Date date = new java.util.Date();
			Timestamp sqlTimeStamp = new java.sql.Timestamp(date.getTime());
			System.out.println("sql-timestamp:" + sqlTimeStamp);

			// ps.setDate(12, (Date) customer.getCUST_CHG_DTM());
			ps.setTimestamp(12, sqlTimeStamp);
			ps.setLong(13, customer.getCUST_ID());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// DELETE
	// --------------------------------------------------------------------------------------------
	public static void Delete(Customer customer) {
		Connection cn = null;
		PreparedStatement ps = null;

		String strSQL = "{ call qryDelete(?,?) }";

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL);

			ps.setLong(1, customer.getCUST_CHG_USER_ID());
			ps.setLong(2, customer.getCUST_ID());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// UNDELETE
	// --------------------------------------------------------------------------------------------
	public static void Undelete(Customer customer) {
		Connection cn = null;
		PreparedStatement ps = null;

		String strSQL = "{ call qryUndelete(?,?) }";

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL);

			ps.setLong(1, customer.getCUST_CHG_USER_ID());
			ps.setLong(2, customer.getCUST_ID());

			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// PURGE
	// --------------------------------------------------------------------------------------------
	public static void Purge() {
		Connection cn = null;
		Statement s = null;

		String strSQL = "DELETE FROM CUT001_CUSTOMER_MSTR WHERE (((CUT001_CUSTOMER_MSTR.CUST_STAT_CD)=\"D\") AND ((DateDiff(\"d\",[CUST_CHG_DTM],Now()))>30));";
		try {
			cn = DriverManager.getConnection(ConnectionString);
			s = cn.createStatement();

			s.execute(strSQL);			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ADD
	// --------------------------------------------------------------------------------------------
	public static long Add(Customer customer) {
		long newId = 0;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("INSERT INTO CUT001_CUSTOMER_MSTR ");
		strSQL.append("(");
		strSQL.append("CUST_FIRST_NM, "); // 1
		strSQL.append("CUST_LAST_NM, "); // 2
		strSQL.append("CUST_ADDR_TXT, "); // 3
		strSQL.append("CUST_CITY_NM, "); // 4
		strSQL.append("CUST_ST_CD, "); // 5
		strSQL.append("CUST_ZIP_CD, "); // 6
		strSQL.append("CUST_EMAIL, "); // 7
		strSQL.append("CUST_PHONE, "); // 8
		strSQL.append("CUST_USERNM, "); // 9
		strSQL.append("CUST_PASSWORD, "); // 10
		strSQL.append("CUST_ADD_USER_ID, "); // 11
		strSQL.append("CUST_STAT_CD"); // 11
		strSQL.append(") ");
		strSQL.append("VALUES ");
		strSQL.append("(");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?, ");
		strSQL.append("?");
		strSQL.append(");");

		// System.out.println(strSQL);

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());

			ps.setString(1, customer.getCUST_FIRST_NM());
			ps.setString(2, customer.getCUST_LAST_NM());
			ps.setString(3, customer.getCUST_ADDR_TXT());
			ps.setString(4, customer.getCUST_CITY_NM());
			ps.setString(5, customer.getCUST_ST_CD());
			ps.setString(6, customer.getCUST_ZIP_CD());
			ps.setString(7, customer.getCUST_EMAIL());
			ps.setString(8, customer.getCUST_PHONE());
			ps.setString(9, customer.getCUST_USERNM());
			ps.setString(10, customer.getCUST_PASSWORD());
			ps.setLong(11, customer.getCUST_ADD_USER_ID());
			ps.setString(12, customer.getCUST_STAT_CD());

			ps.executeUpdate();
			ps.close();

			ps = cn.prepareStatement("SELECT @@IDENTITY AS NEW_ID");
			rs = ps.executeQuery();
			if (rs.next()) {
				newId = rs.getLong("NEW_ID");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return newId;
	}

	// INQUIRE
	// --------------------------------------------------------------------------------------------
	public static Customer Inquire(Customer customer) { // Passed customer
														// object
		return Inquire(customer.getCUST_ID());
	}

	public static Customer Inquire(long CUST_ID) { // Passed customer id
		Customer customer = null;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String strSQL = "{ call qryCustomerByID(?) }";

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL);
			ps.setLong(1, CUST_ID);
			rs = ps.executeQuery();

			while (rs.next()) {
				customer = CustomerDB.Create(rs);
			}
		} catch (Exception e) {
			e.printStackTrace();
			customer = null;
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return customer;
	}

	public static LinkedList<Customer> SearchFirstName(String FirstName) { // Passed
																			// first
		// name
		LinkedList<Customer> results = new LinkedList<Customer>();
		Customer customer = null;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("CUST_ID, ");
		strSQL.append("CUST_FIRST_NM, ");
		strSQL.append("CUST_LAST_NM, ");
		strSQL.append("CUST_ADDR_TXT, ");
		strSQL.append("CUST_CITY_NM, ");
		strSQL.append("CUST_ST_CD, ");
		strSQL.append("CUST_ZIP_CD, ");
		strSQL.append("CUST_EMAIL, ");
		strSQL.append("CUST_PHONE, ");
		strSQL.append("CUST_USERNM,	");
		strSQL.append("CUST_PASSWORD, ");
		strSQL.append("CUST_ADD_USER_ID, ");
		strSQL.append("CUST_ADD_DTM, ");
		strSQL.append("CUST_CHG_USER_ID, ");
		strSQL.append("CUST_CHG_DTM, ");
		strSQL.append("CUST_STAT_CD ");
		strSQL.append("FROM CUT001_CUSTOMER_MSTR ");
		strSQL.append("WHERE CUST_FIRST_NM LIKE ?;");	// PARAMETER INDEX = 1
		
		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
						
			ps.setString(1, FirstName + "%");
			
			rs = ps.executeQuery();

			while (rs.next()) {
				customer = CustomerDB.Create(rs);
				results.addLast(customer);
			}
		} catch (Exception e) {
			 e.printStackTrace();
			customer = null;
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return results;
	}

	public static LinkedList<Customer> SearchLastName(String LastName) { // Passed
																			// last
		// name
		LinkedList<Customer> results = new LinkedList<Customer>();
		Customer customer = null;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("CUST_ID, ");
		strSQL.append("CUST_FIRST_NM, ");
		strSQL.append("CUST_LAST_NM, ");
		strSQL.append("CUST_ADDR_TXT, ");
		strSQL.append("CUST_CITY_NM, ");
		strSQL.append("CUST_ST_CD, ");
		strSQL.append("CUST_ZIP_CD, ");
		strSQL.append("CUST_EMAIL, ");
		strSQL.append("CUST_PHONE, ");
		strSQL.append("CUST_USERNM,	");
		strSQL.append("CUST_PASSWORD, ");
		strSQL.append("CUST_ADD_USER_ID, ");
		strSQL.append("CUST_ADD_DTM, ");
		strSQL.append("CUST_CHG_USER_ID, ");
		strSQL.append("CUST_CHG_DTM, ");
		strSQL.append("CUST_STAT_CD ");
		strSQL.append("FROM CUT001_CUSTOMER_MSTR ");
		strSQL.append("WHERE CUST_LAST_NM LIKE ?;");	// PARAMETER INDEX = 1
		
		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
						
			ps.setString(1, LastName + "%");
			
			rs = ps.executeQuery();

			while (rs.next()) {
				customer = CustomerDB.Create(rs);
				results.addLast(customer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			customer = null;
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return results;
	}

	public static LinkedList<Customer> SearchAllCustomers() {
		LinkedList<Customer> results = new LinkedList<Customer>();
		Customer customer = null;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("CUST_ID, ");
		strSQL.append("CUST_FIRST_NM, ");
		strSQL.append("CUST_LAST_NM, ");
		strSQL.append("CUST_ADDR_TXT, ");
		strSQL.append("CUST_CITY_NM, ");
		strSQL.append("CUST_ST_CD, ");
		strSQL.append("CUST_ZIP_CD, ");
		strSQL.append("CUST_EMAIL, ");
		strSQL.append("CUST_PHONE, ");
		strSQL.append("CUST_USERNM,	");
		strSQL.append("CUST_PASSWORD, ");
		strSQL.append("CUST_ADD_USER_ID, ");
		strSQL.append("CUST_ADD_DTM, ");
		strSQL.append("CUST_CHG_USER_ID, ");
		strSQL.append("CUST_CHG_DTM, ");
		strSQL.append("CUST_STAT_CD ");
		strSQL.append("FROM CUT001_CUSTOMER_MSTR;");

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
			rs = ps.executeQuery();

			while (rs.next()) {
				customer = CustomerDB.Create(rs);
				results.addLast(customer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			customer = null;
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return results;
	}

	public static LinkedList<StateCode> GetStates() {
		LinkedList<StateCode> states = new LinkedList<StateCode>();
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("ST_CD, ST_NM ");
		strSQL.append("FROM CUT002_STATE_CODE ");
		strSQL.append("ORDER BY ST_CD;");

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
			rs = ps.executeQuery();

			while (rs.next()) {
				StateCode sc = new StateCode(rs.getString("ST_CD"), rs.getString("ST_NM"));
				states.addLast(sc);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return states;
	}

	public static StateCode LookUpState(String code) {
		StateCode sc = null;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("ST_CD, ST_NM ");
		strSQL.append("FROM CUT002_STATE_CODE ");
		strSQL.append("WHERE ST_CD = ? ");

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
			ps.setString(1, code);
			rs = ps.executeQuery();

			while (rs.next()) {
				sc = new StateCode(rs.getString("ST_CD"), rs.getString("ST_NM"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return sc;
	}

	public static int GetNextCustID() {
		int last_cust_id = -1;
		Connection cn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		StringBuilder strSQL = new StringBuilder("SELECT ");
		strSQL.append("MAX(CUST_ID) ");
		strSQL.append("FROM CUT001_CUSTOMER_MSTR ");

		try {
			cn = DriverManager.getConnection(ConnectionString);
			ps = cn.prepareStatement(strSQL.toString());
			rs = ps.executeQuery();

			while (rs.next()) {
				last_cust_id = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				cn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return (last_cust_id + 1);
	}
}
