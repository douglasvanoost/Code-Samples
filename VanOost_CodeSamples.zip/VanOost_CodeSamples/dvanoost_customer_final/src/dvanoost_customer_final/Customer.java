package dvanoost_customer_final;

public class Customer {
	private long m_CUST_ID;
	private String m_CUST_FIRST_NM;
	private String m_CUST_LAST_NM;
	private String m_CUST_ADDR_TXT;
	private String m_CUST_CITY_NM;
	private String m_CUST_ST_CD;
	private String m_CUST_ZIP_CD;
	private String m_CUST_EMAIL;
	private String m_CUST_PHONE;
	private String m_CUST_USERNM;
	private String m_CUST_PASSWORD;
	private long m_CUST_ADD_USER_ID;
	private java.util.Date m_CUST_ADD_DTM;
	private long m_CUST_CHG_USER_ID;
	private java.util.Date m_CUST_CHG_DTM;
	private char m_CUST_STAT_CD;

	public Customer() {
		m_CUST_ID = 0;
		m_CUST_FIRST_NM = null;
		m_CUST_LAST_NM = null;
		m_CUST_ADDR_TXT = null;
		m_CUST_CITY_NM = null;
		m_CUST_ST_CD = null;
		m_CUST_ZIP_CD = null;
		m_CUST_EMAIL = null;
		m_CUST_PHONE = null;
		m_CUST_USERNM = null;
		m_CUST_PASSWORD = null;
		m_CUST_ADD_USER_ID = 0;
		m_CUST_ADD_DTM = null;
		m_CUST_CHG_USER_ID = 0;
		m_CUST_CHG_DTM = null;
		m_CUST_STAT_CD = '\0';
	}

	public long getCUST_ID() {
		return m_CUST_ID;
	}

	public void setCUST_ID(long Customer_ID) {
		m_CUST_ID = Customer_ID;
	}

	public String getCUST_FIRST_NM() {
		return m_CUST_FIRST_NM;
	}

	public void setCUST_FIRST_NM(String FirstName) {
		m_CUST_FIRST_NM = FirstName;
	}

	public String getCUST_LAST_NM() {
		return m_CUST_LAST_NM;
	}

	public void setCUST_LAST_NM(String LastName) {
		m_CUST_LAST_NM = LastName;
	}

	public String getCUST_ADDR_TXT() {
		return m_CUST_ADDR_TXT;
	}

	public void setCUST_ADDR_TXT(String Address) {
		m_CUST_ADDR_TXT = Address;
	}

	public String getCUST_CITY_NM() {
		return m_CUST_CITY_NM;
	}

	public void setCUST_CITY_NM(String City) {
		m_CUST_CITY_NM = City;
	}

	public String getCUST_ST_CD() {
		return m_CUST_ST_CD;
	}

	public void setCUST_ST_CD(String StateCode) {
		m_CUST_ST_CD = StateCode;
	}

	public String getCUST_ZIP_CD() {
		return m_CUST_ZIP_CD;
	}

	public void setCUST_ZIP_CD(String ZipCode) {
		m_CUST_ZIP_CD = ZipCode;
	}

	public String getCUST_EMAIL() {
		return m_CUST_EMAIL;
	}

	public void setCUST_EMAIL(String Email) {
		m_CUST_EMAIL = Email;
	}

	public String getCUST_PHONE() {
		return m_CUST_PHONE;
	}

	public void setCUST_PHONE(String PhoneNumber) {
		m_CUST_PHONE = PhoneNumber;
	}

	public String getCUST_USERNM() {
		return m_CUST_USERNM;
	}

	public void setCUST_USERNM(String Username) {
		m_CUST_USERNM = Username;
	}

	public String getCUST_PASSWORD() {
		return m_CUST_PASSWORD;
	}

	public void setCUST_PASSWORD(String Password) {
		m_CUST_PASSWORD = Password;
	}

	public long getCUST_ADD_USER_ID() {
		return m_CUST_ADD_USER_ID;
	}

	public void setCUST_ADD_USER_ID(long Add_UserID) {
		m_CUST_ADD_USER_ID = Add_UserID;
	}

	public java.util.Date getCUST_ADD_DTM() {
		return m_CUST_ADD_DTM;
	}

	public void setCUST_ADD_DTM(java.util.Date Add_DateTime) {
		m_CUST_ADD_DTM = Add_DateTime;
	}

	public long getCUST_CHG_USER_ID() {
		return m_CUST_CHG_USER_ID;
	}

	public void setCUST_CHG_USER_ID(long Change_UserID) {
		m_CUST_CHG_USER_ID = Change_UserID;
	}

	public java.util.Date getCUST_CHG_DTM() {
		return m_CUST_CHG_DTM;
	}

	public void setCUST_CHG_DTM(java.util.Date Change_DateTime) {
		m_CUST_CHG_DTM = Change_DateTime;
	}

	public String getCUST_STAT_CD() {
		return String.valueOf(m_CUST_STAT_CD);
	}

	public void setCUST_STAT_CD(char StatusCode) {
		m_CUST_STAT_CD = StatusCode;
	}
}