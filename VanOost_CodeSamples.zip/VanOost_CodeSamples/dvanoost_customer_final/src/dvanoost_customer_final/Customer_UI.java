package dvanoost_customer_final;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Timestamp;
import java.text.Normalizer.Form;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.lang.ArrayUtils;

public class Customer_UI extends JFrame implements WindowListener, ActionListener {

	// PANELS
	private JPanel homePanel;
	private JPanel addPanel;
	private JPanel searchPanel;
	private JPanel resultsPanel;

	// PANEL COMPONENTS
	private JMenuItem mnuFileAdd;
	private JMenuItem mnuFileSearch;
	private JMenuItem mnuFileUpdate;
	private JMenuItem mnuFileDelete;
	private JMenuItem mnuFileUndelete;
	private JMenuItem mnuFilePurge;
	private JButton btnAdd;
	private JButton btnBack;
	private JComboBox dtaSearchMethod;
	private JTextField dtaSearchKey;

	// FILL DROP DOWN MENU
	private LinkedList<StateCode> StateCodes = CustomerDB.GetStates();
	private String states[] = new String[51];
	{
		states[0] = "";

		for (int i = 0; i < 50; i++)
			states[i + 1] = StateCodes.get(i).toString();
	}

	private JComboBox dtaStateCb = new JComboBox(states);

	// ARRAYS
	private JTextField[] txtFields;
	private JLabel[] txtLabels;

	// VARIABLES
	private boolean goodInputs = true;
	private StringBuilder mssg = new StringBuilder();
	private StringBuilder aboutMsg;

	// CONSTRUCTOR
	public Customer_UI() {
		super();

		setSize(700, 600);

		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();

		int x = (d.width - getWidth()) / 2;
		int y = (d.height - getHeight()) / 2;

		setLocation(x, y);
		setTitle("Customer Database Helper");

		String icon_path = String.format("%s\\IMG_0442.PNG", System.getProperty("user.dir"));

		ImageIcon icon = new ImageIcon(icon_path);

		this.setIconImage(icon.getImage());

		setContentPane(getHomePane());
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public JPanel getHomePane() {
		if (homePanel == null) {
			homePanel = new JPanel();

			homePanel.setLayout(new BorderLayout());

			//
			// MENU PANEL
			JMenuBar menuBar = new JMenuBar();
			JMenu mnuFile = new JMenu("File", true);
			JMenu mnuHelp = new JMenu("Help", true);

			mnuFileAdd = new JMenuItem("Add");
			mnuFileAdd.setActionCommand("HOME_ADD");
			mnuFileAdd.addActionListener(this);
			mnuFile.add(mnuFileAdd);

			mnuFileSearch = new JMenuItem("Search");
			mnuFileSearch.setActionCommand("HOME_SEARCH");
			mnuFileSearch.addActionListener(this);
			mnuFile.add(mnuFileSearch);

			mnuFilePurge = new JMenuItem("Purge");
			mnuFilePurge.setActionCommand("PURGE");
			mnuFilePurge.addActionListener(this);
			mnuFile.add(mnuFilePurge);

			mnuFile.add(new JSeparator());

			JMenuItem mnuFileExit = new JMenuItem("Exit");
			mnuFileExit.setActionCommand("EXIT");
			mnuFileExit.addActionListener(this);
			mnuFile.add(mnuFileExit);

			aboutMsg = new StringBuilder();
			aboutMsg.append("Click a button and see how much fun you can have!\n\n");
			aboutMsg.append("Add: Creates a new customer in the database\n");
			aboutMsg.append("Search: Search the database for a customer\n");
			aboutMsg.append(
					"Purge: Physically delete all the inactive customers\n              that have been in the database for 30 days\n\n");
			JMenuItem mnuHelpAbout = new JMenuItem("About");
			mnuHelpAbout.setActionCommand("ABOUT");
			mnuHelpAbout.addActionListener(this);
			mnuHelp.add(mnuHelpAbout);

			menuBar.add(mnuFile);
			menuBar.add(mnuHelp);

			// WELCOME PANEL
			JPanel wlcmPanel = new JPanel(new FlowLayout());

			JLabel wlcmLbl = new JLabel("Welcome to dvanoost's Customer Database Helper!");
			wlcmLbl.setAlignmentX(CENTER_ALIGNMENT);
			wlcmLbl.setFont(new Font(wlcmLbl.getFont().toString(), 0, 25));
			wlcmPanel.add(wlcmLbl);

			// BUTTON PANEL
			JPanel btnsPanel = new JPanel();
			// btnsPanel.setLayout(new FlowLayout());
			btnsPanel.setBorder(BorderFactory.createEmptyBorder(0, 175, 300, 175));

			btnsPanel.add(Box.createVerticalStrut(10)); // SPACER

			// BUTTONS
			JButton btnAdd = new JButton("Add");
			JButton btnSearch = new JButton("Search");
			JButton btnPurge = new JButton("Purge");
			JButton btnExit = new JButton("Exit");

			btnAdd.setActionCommand("HOME_ADD");
			btnAdd.addActionListener(this);
			btnAdd.setAlignmentX(CENTER_ALIGNMENT);
			btnsPanel.add(btnAdd);

			btnsPanel.add(Box.createVerticalStrut(10)); // SPACER

			btnSearch.setActionCommand("HOME_SEARCH");
			btnSearch.addActionListener(this);
			btnSearch.setAlignmentX(CENTER_ALIGNMENT);
			btnsPanel.add(btnSearch);

			btnsPanel.add(Box.createVerticalStrut(10)); // SPACER

			btnPurge.setActionCommand("PURGE");
			btnPurge.addActionListener(this);
			btnsPanel.add(btnPurge);

			btnsPanel.add(Box.createVerticalStrut(10)); // SPACER

			btnExit.setActionCommand("EXIT");
			btnExit.addActionListener(this);
			btnExit.setAlignmentX(CENTER_ALIGNMENT);
			btnsPanel.add(btnExit);

			homePanel.add(menuBar, BorderLayout.NORTH);
			homePanel.add(wlcmPanel, BorderLayout.CENTER);
			homePanel.add(btnsPanel, BorderLayout.SOUTH);
		}

		return homePanel;
	}

	public JPanel getAddPane() {
		if (addPanel == null) {
			addPanel = new JPanel();

			// ROW 1 OF CONTENT PANE
			// -- MENU PANEL

			// ROW 2 OF CONTENT PANE
			JPanel dataPanel = new JPanel();
			dataPanel.setLayout(new GridLayout(15, 3));
			dataPanel.setBorder(new EmptyBorder(80, 80, 00, 00));

			// ROW 3 OF CONTENT PANE
			JPanel buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());

			addPanel.setLayout(new BorderLayout());

			//
			// MENU PANEL
			JMenuBar menuBar = new JMenuBar();
			JMenu mnuFile = new JMenu("File", true);
			JMenu mnuHelp = new JMenu("Help", true);

			mnuFileAdd = new JMenuItem("Add");
			mnuFileAdd.setActionCommand("ADD");
			mnuFileAdd.addActionListener(this);
			mnuFile.add(mnuFileAdd);

			mnuFile.add(new JSeparator());

			JMenuItem mnuFileExit = new JMenuItem("Exit");
			mnuFileExit.setActionCommand("EXIT");
			mnuFileExit.addActionListener(this);
			mnuFile.add(mnuFileExit);

			aboutMsg = new StringBuilder();
			aboutMsg.append("Fill out the form and press the add button to save the customer to the database.");
			JMenuItem mnuHelpAbout = new JMenuItem("About");
			mnuHelpAbout.setActionCommand("ABOUT");
			mnuHelpAbout.addActionListener(this);
			mnuHelp.add(mnuHelpAbout);

			menuBar.add(mnuFile);
			menuBar.add(mnuHelp);

			//
			// DATA PANEL
			//
			// LABELS
			//
			JLabel dtaIdLbl = new JLabel("Customer ID:  ", SwingConstants.RIGHT);
			JLabel dtaFNameLbl = new JLabel("First Name:  ", SwingConstants.RIGHT);
			JLabel dtaLNameLbl = new JLabel("Last Name:  ", SwingConstants.RIGHT);
			JLabel dtaAddressLbl = new JLabel("Address:  ", SwingConstants.RIGHT);
			JLabel dtaCityLbl = new JLabel("City:  ", SwingConstants.RIGHT);
			JLabel dtaStateLbl = new JLabel("State:  ", SwingConstants.RIGHT);
			JLabel dtaZipLbl = new JLabel("Zip Code:  ", SwingConstants.RIGHT);
			JLabel dtaEmailLbl = new JLabel("Email:  ", SwingConstants.RIGHT);
			JLabel dtaPhoneLbl = new JLabel("Phone:  ", SwingConstants.RIGHT);
			JLabel dtaUsernameLbl = new JLabel("Username:  ", SwingConstants.RIGHT);
			JLabel dtaPasswordLbl = new JLabel("Password:  ", SwingConstants.RIGHT);
			JLabel dtaAddUserIdLbl = new JLabel("Add User Id:  ", SwingConstants.RIGHT);
			JLabel dtaAddDtmLbl = new JLabel("Add Date / Time:  ", SwingConstants.RIGHT);

			txtLabels = new JLabel[12];
			txtLabels[0] = dtaIdLbl;
			txtLabels[1] = dtaFNameLbl;
			txtLabels[2] = dtaLNameLbl;
			txtLabels[3] = dtaAddressLbl;
			txtLabels[4] = dtaCityLbl;
			txtLabels[5] = dtaZipLbl;
			txtLabels[6] = dtaEmailLbl;
			txtLabels[7] = dtaPhoneLbl;
			txtLabels[8] = dtaUsernameLbl;
			txtLabels[9] = dtaPasswordLbl;
			txtLabels[10] = dtaAddUserIdLbl;
			txtLabels[11] = dtaAddDtmLbl;

			//
			// TXT FIELDS
			//
			JTextField dtaIdTxt = new JTextField();
			JTextField dtaFNameTxt = new JTextField();
			JTextField dtaLNameTxt = new JTextField();
			JTextField dtaAddressTxt = new JTextField();
			JTextField dtaCityTxt = new JTextField();
			// STATE IS DROP DOWN
			JTextField dtaZipTxt = new JTextField();
			JTextField dtaEmailTxt = new JTextField();
			JTextField dtaPhoneTxt = new JTextField();
			JTextField dtaUsernameTxt = new JTextField();
			JTextField dtaPasswordTxt = new JTextField();
			JTextField dtaAddUserIdTxt = new JTextField();
			JTextField dtaAddDtmTxt = new JTextField();

			txtFields = new JTextField[11];
			txtFields[0] = dtaIdTxt;
			txtFields[1] = dtaFNameTxt;
			txtFields[2] = dtaLNameTxt;
			txtFields[3] = dtaAddressTxt;
			txtFields[4] = dtaCityTxt;
			txtFields[5] = dtaZipTxt;
			txtFields[6] = dtaEmailTxt;
			txtFields[7] = dtaPhoneTxt;
			txtFields[8] = dtaUsernameTxt;
			txtFields[9] = dtaPasswordTxt;
			txtFields[10] = dtaAddUserIdTxt;
			// txtFields[11] = dtaAddDtmTxt;

			dtaIdTxt.setEnabled(false);
			dtaIdTxt.setText(String.valueOf(CustomerDB.GetNextCustID()));

			String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
			dtaAddDtmTxt.enable(false);
			dtaAddDtmTxt.setDisabledTextColor(Color.BLACK);
			dtaAddDtmTxt.setText(timeStamp);

			dataPanel.add(dtaIdLbl);
			dataPanel.add(dtaIdTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaFNameLbl);
			dataPanel.add(dtaFNameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaLNameLbl);
			dataPanel.add(dtaLNameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddressLbl);
			dataPanel.add(dtaAddressTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaCityLbl);
			dataPanel.add(dtaCityTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaStateLbl);
			dataPanel.add(dtaStateCb);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaZipLbl);
			dataPanel.add(dtaZipTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaEmailLbl);
			dataPanel.add(dtaEmailTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaPhoneLbl);
			dataPanel.add(dtaPhoneTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaUsernameLbl);
			dataPanel.add(dtaUsernameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaPasswordLbl);
			dataPanel.add(dtaPasswordTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddUserIdLbl);
			dataPanel.add(dtaAddUserIdTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddDtmLbl);
			dataPanel.add(dtaAddDtmTxt);
			dataPanel.add(new JLabel(" "));

			//
			// BUTTON PANEL
			btnBack = new JButton("Back");
			btnAdd = new JButton("Add");
			JButton btnExit = new JButton("Exit");

			btnBack.setActionCommand("BACK");
			btnBack.addActionListener(this);
			buttonPanel.add(btnBack);

			buttonPanel
					.add(new JLabel("                                                                               "));

			btnAdd.setActionCommand("ADD");
			btnAdd.addActionListener(this);
			buttonPanel.add(btnAdd);

			buttonPanel
					.add(new JLabel("                                                                               "));

			btnExit.setActionCommand("EXIT");
			btnExit.addActionListener(this);
			buttonPanel.add(btnExit);

			//
			// CONTENT PANE
			addPanel.add(menuBar, BorderLayout.NORTH);
			addPanel.add(dataPanel, BorderLayout.CENTER);
			addPanel.add(buttonPanel, BorderLayout.SOUTH);
		}
		return addPanel;
	}

	public JPanel getSearchPane() {
		if (searchPanel == null) {
			searchPanel = new JPanel();

			// ROW 1 OF CONTENT PANE
			// -- MENU PANEL

			// ROW 2 OF CONTENT PANE
			JPanel dataPanel = new JPanel();
			dataPanel.setLayout(new GridLayout(15, 3));
			dataPanel.setBorder(new EmptyBorder(10, 10, 00, 00));

			// ROW 3 OF CONTENT PANE
			JPanel buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());

			searchPanel.setLayout(new BorderLayout());

			//
			// MENU PANEL
			JMenuBar menuBar = new JMenuBar();
			JMenu mnuFile = new JMenu("File", true);
			JMenu mnuHelp = new JMenu("Help", true);

			mnuFileSearch = new JMenuItem("Search");
			mnuFileSearch.setActionCommand("SEARCH");
			mnuFileSearch.addActionListener(this);
			mnuFile.add(mnuFileSearch);

			mnuFile.add(new JSeparator());

			JMenuItem mnuFileExit = new JMenuItem("Exit");
			mnuFileExit.setActionCommand("EXIT");
			mnuFileExit.addActionListener(this);
			mnuFile.add(mnuFileExit);

			aboutMsg = new StringBuilder();
			aboutMsg.append(
					"Pick the search method from the drop down menu.\nInput the key to search for, then press search.");
			JMenuItem mnuHelpAbout = new JMenuItem("About");
			mnuHelpAbout.setActionCommand("ABOUT");
			mnuHelpAbout.addActionListener(this);
			mnuHelp.add(mnuHelpAbout);

			menuBar.add(mnuFile);
			menuBar.add(mnuHelp);

			//
			// DATA PANEL
			//
			// LABELS
			//
			JLabel dtaPromptLbl = new JLabel("Select Search Method: ");
			String[] options = { "Customer ID", "First Name", "Last Name", "All Customers" };
			dtaSearchMethod = new JComboBox(options);
			dtaSearchKey = new JTextField();

			txtFields = new JTextField[1];
			txtFields[0] = dtaSearchKey;

			JButton btnSearch = new JButton("Search");
			btnSearch.setActionCommand("SEARCH");
			btnSearch.addActionListener(this);

			dataPanel.add(new JLabel(" "));
			dataPanel.add(dtaPromptLbl);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(new JLabel(" "));
			dataPanel.add(dtaSearchMethod);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(new JLabel(" "));
			dataPanel.add(dtaSearchKey);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(new JLabel(" "));
			dataPanel.add(new JLabel(" "));
			dataPanel.add(new JLabel(" "));

			dataPanel.add(new JLabel(" "));
			dataPanel.add(btnSearch);

			for (int i = 0; i < 30; i++) {
				dataPanel.add(new JLabel(" ")); // 30 EMPTY LABELS = 10 EMPTY
												// ROW
			}

			//
			// BUTTON PANEL
			btnBack = new JButton("Back");
			JButton btnExit = new JButton("Exit");

			btnBack.setActionCommand("SEARCH_BACK");
			btnBack.addActionListener(this);
			buttonPanel.add(btnBack);

			buttonPanel.add(Box.createHorizontalStrut(535)); // SPACER

			btnExit.setActionCommand("EXIT");
			btnExit.addActionListener(this);
			buttonPanel.add(btnExit);

			//
			// CONTENT PANE
			searchPanel.add(menuBar, BorderLayout.NORTH);
			searchPanel.add(dataPanel, BorderLayout.CENTER);
			searchPanel.add(buttonPanel, BorderLayout.SOUTH);
		}
		return searchPanel;
	}

	public JPanel getResultsPane(Customer customer) {
		if (resultsPanel == null) {
			resultsPanel = new JPanel();

			// ROW 1 OF CONTENT PANE
			JPanel menuPanel = new JPanel();
			menuPanel.setLayout(new FlowLayout((int) this.LEFT_ALIGNMENT));

			// ROW 2 OF CONTENT PANE
			JPanel dataPanel = new JPanel();
			dataPanel.setLayout(new GridLayout(16, 3));
			dataPanel.setBorder(new EmptyBorder(10, 10, 00, 00));

			// ROW 3 OF CONTENT PANE
			JPanel buttonPanel = new JPanel();
			buttonPanel.setLayout(new FlowLayout());

			resultsPanel.setLayout(new BorderLayout());

			//
			// MENU PANEL
			JMenuBar menuBar = new JMenuBar();
			JMenu mnuFile = new JMenu("File", true);
			JMenu mnuHelp = new JMenu("Help", true);

			mnuFileUpdate = new JMenuItem("Update");
			mnuFileUpdate.setActionCommand("UPDATE");
			mnuFileUpdate.addActionListener(this);
			mnuFile.add(mnuFileUpdate);

			mnuFileDelete = new JMenuItem("Delete");
			mnuFileDelete.setActionCommand("DELETE");
			mnuFileDelete.addActionListener(this);
			mnuFile.add(mnuFileDelete);

			mnuFileUndelete = new JMenuItem("Undelete");
			mnuFileUndelete.setActionCommand("UNDELETE");
			mnuFileUndelete.addActionListener(this);
			mnuFile.add(mnuFileUndelete);

			mnuFile.add(new JSeparator());

			JMenuItem mnuFileExit = new JMenuItem("Exit");
			mnuFileExit.setActionCommand("EXIT");
			mnuFileExit.addActionListener(this);
			mnuFile.add(mnuFileExit);

			aboutMsg = new StringBuilder();
			aboutMsg.append("Update: Make changes to the form and press update to save the changes to the database.\n");
			aboutMsg.append("Delete: Change the status code of the customer from Deleted to Active.\n");
			aboutMsg.append("Undelete: Change the status code of the customer from Active to Deleted.");
			JMenuItem mnuHelpAbout = new JMenuItem("About");
			mnuHelpAbout.setActionCommand("ABOUT");
			mnuHelpAbout.addActionListener(this);
			mnuHelp.add(mnuHelpAbout);

			menuBar.add(mnuFile);
			menuBar.add(mnuHelp);

			//
			// DATA PANEL
			//
			// LABELS
			//
			JLabel dtaIdLbl = new JLabel("Customer ID:  ", SwingConstants.RIGHT);
			JLabel dtaFNameLbl = new JLabel("First Name:  ", SwingConstants.RIGHT);
			JLabel dtaLNameLbl = new JLabel("Last Name:  ", SwingConstants.RIGHT);
			JLabel dtaAddressLbl = new JLabel("Address:  ", SwingConstants.RIGHT);
			JLabel dtaCityLbl = new JLabel("City:  ", SwingConstants.RIGHT);
			JLabel dtaStateLbl = new JLabel("State:  ", SwingConstants.RIGHT);
			JLabel dtaZipLbl = new JLabel("Zip Code:  ", SwingConstants.RIGHT);
			JLabel dtaEmailLbl = new JLabel("Email:  ", SwingConstants.RIGHT);
			JLabel dtaPhoneLbl = new JLabel("Phone:  ", SwingConstants.RIGHT);
			JLabel dtaUsernameLbl = new JLabel("Username:  ", SwingConstants.RIGHT);
			JLabel dtaPasswordLbl = new JLabel("Password:  ", SwingConstants.RIGHT);
			JLabel dtaAddUserIdLbl = new JLabel("Add User Id:  ", SwingConstants.RIGHT);
			JLabel dtaAddDtmLbl = new JLabel("Add Date / Time:  ", SwingConstants.RIGHT);
			JLabel dtaChgUserIdLbl = new JLabel("Change User Id:  ", SwingConstants.RIGHT);
			JLabel dtaChgDtmLbl = new JLabel("Change Date / Time:  ", SwingConstants.RIGHT);
			JLabel dtaStatCdLbl = new JLabel("Status:  ", SwingConstants.RIGHT);

			txtLabels = new JLabel[15];
			txtLabels[0] = dtaIdLbl;
			txtLabels[1] = dtaFNameLbl;
			txtLabels[2] = dtaLNameLbl;
			txtLabels[3] = dtaAddressLbl;
			txtLabels[4] = dtaCityLbl;
			txtLabels[5] = dtaZipLbl;
			txtLabels[6] = dtaEmailLbl;
			txtLabels[7] = dtaPhoneLbl;
			txtLabels[8] = dtaUsernameLbl;
			txtLabels[9] = dtaPasswordLbl;
			txtLabels[10] = dtaAddUserIdLbl;
			txtLabels[11] = dtaAddDtmLbl;
			txtLabels[12] = dtaChgUserIdLbl;
			txtLabels[13] = dtaChgDtmLbl;
			txtLabels[14] = dtaStatCdLbl;

			//
			// TXT FIELDS
			//
			JTextField dtaIdTxt = new JTextField(String.valueOf(customer.getCUST_ID()));
			JTextField dtaFNameTxt = new JTextField(customer.getCUST_FIRST_NM());
			JTextField dtaLNameTxt = new JTextField(customer.getCUST_LAST_NM());
			JTextField dtaAddressTxt = new JTextField(customer.getCUST_ADDR_TXT());
			JTextField dtaCityTxt = new JTextField(customer.getCUST_CITY_NM());

			// STATE IS DROP DOWN
			int index = -1;
			// TO DO: BAD BECAUSE O(N)! LOOK FOR BETTER SOLUTION
			for (int i = 0; i < states.length; i++) {
				if (states[i].equals(CustomerDB.LookUpState(customer.getCUST_ST_CD()).toString())) {
					index = i;
					break;
				}
			}
			dtaStateCb.setSelectedIndex(index);

			JTextField dtaZipTxt = new JTextField(customer.getCUST_ZIP_CD());
			JTextField dtaEmailTxt = new JTextField(customer.getCUST_EMAIL());
			JTextField dtaPhoneTxt = new JTextField(customer.getCUST_PHONE());
			JTextField dtaUsernameTxt = new JTextField(customer.getCUST_USERNM());
			JTextField dtaPasswordTxt = new JTextField(customer.getCUST_PASSWORD());
			JTextField dtaAddUserIdTxt = new JTextField(String.valueOf(customer.getCUST_ADD_USER_ID()));
			JTextField dtaAddDtmTxt = new JTextField(String.valueOf(customer.getCUST_ADD_DTM()));
			JTextField dtaChgUserIdTxt = new JTextField(String.valueOf(customer.getCUST_CHG_USER_ID()));
			JTextField dtaChgDtmTxt = new JTextField(String.valueOf(customer.getCUST_CHG_DTM()));
			JTextField dtaStatCdTxt = new JTextField(customer.getCUST_STAT_CD());

			txtFields = new JTextField[15];
			txtFields[0] = dtaIdTxt;
			txtFields[1] = dtaFNameTxt;
			txtFields[2] = dtaLNameTxt;
			txtFields[3] = dtaAddressTxt;
			txtFields[4] = dtaCityTxt;
			txtFields[5] = dtaZipTxt;
			txtFields[6] = dtaEmailTxt;
			txtFields[7] = dtaPhoneTxt;
			txtFields[8] = dtaUsernameTxt;
			txtFields[9] = dtaPasswordTxt;
			txtFields[10] = dtaAddUserIdTxt;
			txtFields[11] = dtaAddDtmTxt;
			txtFields[12] = dtaChgUserIdTxt;
			txtFields[13] = dtaChgDtmTxt;
			txtFields[14] = dtaStatCdTxt;

			Date date_now = new Date();
			SimpleDateFormat frmt = new SimpleDateFormat("MM.dd.yyyy hh:mm:ss a zzz");

			dtaIdTxt.enable(false);
			dtaIdTxt.setDisabledTextColor(Color.BLACK);
			dtaAddUserIdTxt.enable(false);
			dtaAddUserIdTxt.setDisabledTextColor(Color.BLACK);
			dtaAddDtmTxt.enable(false);
			dtaAddDtmTxt.setDisabledTextColor(Color.BLACK);
			dtaChgDtmTxt.enable(false);
			dtaChgDtmTxt.setDisabledTextColor(Color.BLACK);
			dtaStatCdTxt.enable(false);
			dtaStatCdTxt.setDisabledTextColor(Color.BLACK);

			dataPanel.add(dtaIdLbl);
			dataPanel.add(dtaIdTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaFNameLbl);
			dataPanel.add(dtaFNameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaLNameLbl);
			dataPanel.add(dtaLNameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddressLbl);
			dataPanel.add(dtaAddressTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaCityLbl);
			dataPanel.add(dtaCityTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaStateLbl);
			dataPanel.add(dtaStateCb);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaZipLbl);
			dataPanel.add(dtaZipTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaEmailLbl);
			dataPanel.add(dtaEmailTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaPhoneLbl);
			dataPanel.add(dtaPhoneTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaUsernameLbl);
			dataPanel.add(dtaUsernameTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaPasswordLbl);
			dataPanel.add(dtaPasswordTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddUserIdLbl);
			dataPanel.add(dtaAddUserIdTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaAddDtmLbl);
			dataPanel.add(dtaAddDtmTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaChgUserIdLbl);
			dataPanel.add(dtaChgUserIdTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaChgDtmLbl);
			dataPanel.add(dtaChgDtmTxt);
			dataPanel.add(new JLabel(" "));

			dataPanel.add(dtaStatCdLbl);
			dataPanel.add(dtaStatCdTxt);
			dataPanel.add(new JLabel(" "));

			//
			// BUTTON PANEL
			btnBack = new JButton("Home");
			JButton btnUpdate = new JButton("Update");
			JButton btnDelete = new JButton("Delete");
			JButton btnUndelete = new JButton("Undelete");
			JButton btnExit = new JButton("Exit");

			btnBack.setActionCommand("HOME");
			btnBack.addActionListener(this);
			buttonPanel.add(btnBack);

			buttonPanel.add(Box.createHorizontalStrut(140)); // SPACER

			btnUpdate.setActionCommand("UPDATE");
			btnUpdate.addActionListener(this);
			buttonPanel.add(btnUpdate);

			btnDelete.setActionCommand("DELETE");
			btnDelete.addActionListener(this);
			buttonPanel.add(btnDelete);

			btnUndelete.setActionCommand("UNDELETE");
			btnUndelete.addActionListener(this);
			buttonPanel.add(btnUndelete);

			buttonPanel.add(Box.createHorizontalStrut(140)); // SPACER

			btnExit.setActionCommand("EXIT");
			btnExit.addActionListener(this);
			buttonPanel.add(btnExit);

			//
			// CONTENT PANE
			resultsPanel.add(menuBar, BorderLayout.NORTH);
			resultsPanel.add(dataPanel, BorderLayout.CENTER);
			resultsPanel.add(buttonPanel, BorderLayout.SOUTH);
		}
		return resultsPanel;
	}

	public static void main(String[] args) {

		Customer_UI form = new Customer_UI();

	}

	private StringBuilder ValidateTxtFields() {
		StringBuilder message = new StringBuilder();
		goodInputs = true;

		// CHECK FOR EMPTY TEXT FIELDS
		for (int i = 0; i < txtFields.length; i++) {
			if (txtFields[i].getText().trim().length() == 0) {
				goodInputs = false;
				message.append("Please check field: "
						+ txtLabels[i].getText().substring(0, txtLabels[i].getText().length() - 3) + "\n");
			}
		}

		// VALIDATE CHOSEN STATE
		if (dtaStateCb.getSelectedItem().toString().trim().length() == 0) {
			goodInputs = false;
			message.append("Please check field: State\n");
		}

		// VALIDATE ZIP CODE
		try {
			Integer.parseInt(txtFields[5].getText());
		} catch (NumberFormatException e) {
			message.append("Please check field: "
					+ txtLabels[5].getText().substring(0, txtLabels[5].getText().length() - 3) + "\n");
		} catch (Exception e) {
			e.printStackTrace();
		}

		// VALIDATE EMAIL
		Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);

		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(txtFields[6].getText());
		
		if(!matcher.find())
		{
			message.append("Please check field: "
					+ txtLabels[6].getText().substring(0, txtLabels[6].getText().length() - 3) + "\n");
		}
		
		// VALIDATE PHONE NUMBER
		try {
			System.out.println(Integer.parseInt(txtFields[7].getText()));
		} catch (NumberFormatException e) {
			message.append("Please check field: "
					+ txtLabels[7].getText().substring(0, txtLabels[7].getText().length() - 3) + "\n");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return message;
	}

	private void AddCustomer() {
		mssg = ValidateTxtFields();

		if (goodInputs) // THIS SHOULD MEAN ALL FIELDS HAVE SOMETHING IN THEM
		{
			Customer add_this = new Customer();

			add_this.setCUST_ID(Long.parseLong(txtFields[0].getText()));
			add_this.setCUST_FIRST_NM(txtFields[1].getText());
			add_this.setCUST_LAST_NM(txtFields[2].getText());
			add_this.setCUST_ADDR_TXT(txtFields[3].getText());
			add_this.setCUST_CITY_NM(txtFields[4].getText());

			String selected = dtaStateCb.getSelectedItem().toString();
			add_this.setCUST_ST_CD(selected.substring(0, 2));

			add_this.setCUST_ZIP_CD(txtFields[5].getText());
			add_this.setCUST_EMAIL(txtFields[6].getText());
			add_this.setCUST_PHONE(txtFields[7].getText());
			add_this.setCUST_USERNM(txtFields[8].getText());
			add_this.setCUST_PASSWORD(txtFields[9].getText());
			add_this.setCUST_ADD_USER_ID(Long.parseLong(txtFields[10].getText()));
			// add_this.setCUST_ADD_DTM not needed bc access db defaults to
			// Now()
			add_this.setCUST_STAT_CD('A');

			CustomerDB.Add(add_this);
			mssg.append("Customer added!");

			// CLEAR ALL TXT BOXES ONCE CUSTOMER IS INPUT
			for (int i = 0; i < txtFields.length; i++) {
				txtFields[i].setText("");
			}
			txtFields[0].setText(String.valueOf(CustomerDB.GetNextCustID()));
			dtaStateCb.setSelectedIndex(0); // 0 IS MY "" (BLANK) OPTION
		}

		JOptionPane.showMessageDialog(null, mssg.toString(), "Add Customer", JOptionPane.INFORMATION_MESSAGE);
	}

	private void UpdateCustomer() {
		mssg = ValidateTxtFields();

		if (goodInputs) // THIS SHOULD MEAN ALL FIELDS HAVE SOMETHING IN THEM
		{
			long current_id = Long.parseLong(txtFields[0].getText());
			Customer current_customer = CustomerDB.Inquire(current_id);

			current_customer.setCUST_ID(Long.parseLong(txtFields[0].getText()));
			current_customer.setCUST_FIRST_NM(txtFields[1].getText());
			current_customer.setCUST_LAST_NM(txtFields[2].getText());
			current_customer.setCUST_ADDR_TXT(txtFields[3].getText());
			current_customer.setCUST_CITY_NM(txtFields[4].getText());

			String selected = dtaStateCb.getSelectedItem().toString();
			current_customer.setCUST_ST_CD(selected.substring(0, 2));

			current_customer.setCUST_ZIP_CD(txtFields[5].getText());
			current_customer.setCUST_EMAIL(txtFields[6].getText());
			current_customer.setCUST_PHONE(txtFields[7].getText());
			current_customer.setCUST_USERNM(txtFields[8].getText());
			current_customer.setCUST_PASSWORD(txtFields[9].getText());
			current_customer.setCUST_ADD_USER_ID(Long.parseLong(txtFields[10].getText()));
			current_customer.setCUST_CHG_USER_ID(Long.parseLong(txtFields[12].getText()));

			SimpleDateFormat frmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			if (txtFields[13].getText().equals(null) || txtFields[13].getText().equals("null")
					|| txtFields[13].getText().equals("")) {
				Date date = new Date();
				String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(date);
				txtFields[13].enable(false);
				txtFields[13].setDisabledTextColor(Color.BLACK);
				txtFields[13].setText(timeStamp);
			}

			try {
				current_customer.setCUST_CHG_DTM(frmt.parse(txtFields[13].getText()));
			} catch (ParseException e) {
				// e.printStackTrace();
			}

			CustomerDB.Update(current_customer);
			mssg.append("Customer updated!");
		}

		JOptionPane.showMessageDialog(null, mssg.toString(), "Update Customer", JOptionPane.INFORMATION_MESSAGE);
	}

	private void DeleteCustomer() {
		goodInputs = true;

		mssg = new StringBuilder();

		if (goodInputs) // THIS SHOULD MEAN ALL FIELDS HAVE SOMETHING IN THEM
		{
			long current_id = Long.parseLong(txtFields[0].getText());
			Customer current_customer = CustomerDB.Inquire(current_id);

			CustomerDB.Delete(current_customer);
			current_customer.setCUST_STAT_CD('D');
			txtFields[14].setText(current_customer.getCUST_STAT_CD());

			Date date = new Date();
			String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(date);
			txtFields[13].enable(false);
			txtFields[13].setDisabledTextColor(Color.BLACK);
			txtFields[13].setText(timeStamp);

			mssg.append("Customer Deleted");
		}

		JOptionPane.showMessageDialog(null, mssg.toString(), "Delete Customer", JOptionPane.INFORMATION_MESSAGE);
	}

	private void UndeleteCustomer() {
		goodInputs = true;

		mssg = new StringBuilder();

		if (goodInputs) // THIS SHOULD MEAN ALL FIELDS HAVE SOMETHING IN THEM
		{
			long current_id = Long.parseLong(txtFields[0].getText());
			Customer current_customer = CustomerDB.Inquire(current_id);

			CustomerDB.Delete(current_customer);
			current_customer.setCUST_STAT_CD('A');
			txtFields[14].setText(current_customer.getCUST_STAT_CD());
			mssg.append("Customer Undeleted");
		}

		JOptionPane.showMessageDialog(null, mssg.toString(), "Undelete Customer", JOptionPane.INFORMATION_MESSAGE);
	}

	private void PurgeCustomer() {
		mssg = new StringBuilder();

		int confirm_purge = JOptionPane.showConfirmDialog(null,
				"You are about to permanatly remove all customers that have\n    been deleted for more than 30 days from the database!\n\n"
						+ "                    !!!!! THIS CAN NOT BE UNDONE !!!!!\n"
						+ "                                  Confirm Purge?\n",
				"Purge", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

		if (confirm_purge == JOptionPane.YES_OPTION) {
			CustomerDB.Purge();
			mssg.append("Purged customers that have been deleted for more than 30 days.");
		} else {
			mssg.append("Purge canceled.");
		}
		JOptionPane.showMessageDialog(null, mssg.toString(), "Purge", JOptionPane.INFORMATION_MESSAGE);
	}

	private void SearchCustomer() {
		goodInputs = true;
		mssg = new StringBuilder();
		LinkedList<Customer> resultsList = new LinkedList<Customer>();

		if (dtaSearchMethod.getSelectedIndex() == 3)
			dtaSearchKey.setText("All Customers");

		if (dtaSearchKey.getText().trim().length() == 0) {
			JOptionPane.showMessageDialog(null, "Enter a key to search off", "Invalid Search Key",
					JOptionPane.INFORMATION_MESSAGE);
			goodInputs = false;
		} else // THIS SHOULD MEAN KEY HAS SOMETHING
		{
			Customer searchResult = null;

			// CUSTOMER ID
			if (dtaSearchMethod.getSelectedIndex() == 0) {
				try {
					Long.parseLong(dtaSearchKey.getText());
					searchResult = CustomerDB.Inquire(Long.parseLong(dtaSearchKey.getText()));
					showResults(searchResult);
				} catch (NumberFormatException e) {
					// NOT A LONG
					searchResult = null;
					mssg.append("Enter a long to search for Customer ID");
				} catch (Exception e) {
					mssg.append("Error: " + e.getMessage());
				}
			}

			// CUSTOMER FIRST NAME
			else if (dtaSearchMethod.getSelectedIndex() == 1) {
				resultsList = CustomerDB.SearchFirstName(dtaSearchKey.getText());
				showResultsTable(resultsList);
			}

			// CUSTOMER LAST NAME
			else if (dtaSearchMethod.getSelectedIndex() == 2) {
				resultsList = CustomerDB.SearchLastName(dtaSearchKey.getText());
				showResultsTable(resultsList);
			}

			// ALL CUSTOMERS
			else if (dtaSearchMethod.getSelectedIndex() == 3) {
				resultsList = CustomerDB.SearchAllCustomers();
				showResultsTable(resultsList);
			}
		}
	}

	private void showResultsTable(LinkedList<Customer> SearchResults) {
		if (SearchResults.size() > 0) {
			String[] columnNames = { "Customer ID", "First Name", "Last Name" };

			Object[][] data = new Object[SearchResults.size()][3];

			for (int i = 0; i < SearchResults.size(); i++) {
				Customer c = (Customer) SearchResults.get(i);
				data[i][0] = c.getCUST_ID();
				data[i][1] = c.getCUST_FIRST_NM();
				data[i][2] = c.getCUST_LAST_NM();
			}

			JTable resultsTable = new JTable(data, columnNames);
			JScrollPane scrollPane = new JScrollPane(resultsTable);
			resultsTable.setFillsViewportHeight(true);

			int choice = JOptionPane.showOptionDialog(null, scrollPane, "Search Results", JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE, null, new String[] { "Select", "Cancel" }, null);

			if (choice == 0) { // "SELECT" CHOSEN
				long selectedCustomerID = Long
						.parseLong(resultsTable.getValueAt(resultsTable.getSelectedRow(), 0).toString());
				showResults(CustomerDB.Inquire(selectedCustomerID));
			}
		} else
			JOptionPane.showMessageDialog(null, "No results found.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
	}

	private void showResults(Customer ResultCustomer) {
		if (ResultCustomer != null) {
			mssg.append("Customer Information Pulled From Database!\n\n");
			mssg.append("Click the About option under the Help tab in the menu for information.");

			// SHOW RESULTS
			setContentPane(getResultsPane(ResultCustomer));
			resultsPanel = null;
			revalidate();
			repaint();
		} else {
			mssg.append("Customer not found.");
		}
		JOptionPane.showMessageDialog(null, mssg.toString(), "Customer Search Results",
				JOptionPane.INFORMATION_MESSAGE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// JOptionPane.showMessageDialog(this, e.getActionCommand());

		switch (e.getActionCommand()) {
		// HOME BUTTON CASES
		case "HOME_ADD":
			setContentPane(getAddPane());
			revalidate();
			repaint();
			break;

		case "HOME_SEARCH":
			setContentPane(getSearchPane());
			revalidate();
			repaint();
			break;

		case "PURGE":
			PurgeCustomer();
			break;

		case "BACK":
			if (txtFields.length != 0) {
				for (int i = 0; i < txtFields.length; i++) {
					txtFields[i].setText("");
				}
				dtaStateCb.setSelectedIndex(0);
			}
			setContentPane(getHomePane());
			revalidate();
			repaint();
			break;

		// [SEARCH / RESULTS]
		case "SEARCH_BACK":
			dtaSearchMethod.setSelectedIndex(0);
			dtaSearchKey.setText("");
			setContentPane(getHomePane());
			revalidate();
			repaint();
			break;

		case "HOME":
			if (txtFields.length != 0) {
				for (int i = 0; i < txtFields.length; i++) {
					txtFields[i].setText("");
				}
				dtaStateCb.setSelectedIndex(0);
			}
			dtaSearchMethod.setSelectedIndex(0);
			dtaSearchKey.setText("");
			setContentPane(getHomePane());
			revalidate();
			repaint();
			break;

		// [ALL] DATA SCREEN BUTTON CASES
		case "ADD":
			AddCustomer();
			revalidate();
			break;

		case "SEARCH":
			SearchCustomer();
			revalidate();
			break;

		case "UPDATE":
			UpdateCustomer();
			revalidate();
			break;

		case "DELETE":
			DeleteCustomer();
			revalidate();
			break;

		case "UNDELETE":
			UndeleteCustomer();
			revalidate();
			break;

		// ALL PANES
		case "EXIT":
			System.exit(0);
			break;

		case "ABOUT":
			JOptionPane.showMessageDialog(this, aboutMsg.toString(), "About", JOptionPane.INFORMATION_MESSAGE);
			break;

		default:
			JOptionPane.showMessageDialog(this, String.format("Unknown command: %s", e.getActionCommand()),
					"Unknown Action", JOptionPane.INFORMATION_MESSAGE);
		}

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
