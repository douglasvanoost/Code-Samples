package dvanoost_customer_final;

public class StateCode {
	private String m_code;
	private String m_name;
	
	public StateCode(String code, String name){
		m_code = code; 
		m_name = name;
	}
	
	public String getCode(){
		return m_code;
	}
	
	public String getName(){
		return m_name;
	}
	
	public String toString(){
		return m_code + " - " + m_name;
	}
}
