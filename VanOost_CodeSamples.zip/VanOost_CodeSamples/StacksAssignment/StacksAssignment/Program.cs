﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StacksAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Doug's Calculator!");
            
            Calculator calculator = new Calculator();
            bool done = false;
            string enterMessage = "Enter equation: num1 (+, -, *, /) num2, type 'Clear' to reset running toal, or type 'Exit' to quit";

            Console.WriteLine("Keep going as long as you'd like.");
            Console.WriteLine(enterMessage);

            while (!done)
            {
                Console.Write("\n> ");
                string nextEquation = Console.ReadLine();
                string[] input = nextEquation.Split(' ');       //could be stronger

                if (nextEquation.ToUpper() == "UNDO")
                {
                    calculator.Undo();                      //get the value to display from the calculator
                }
                else if (nextEquation.ToUpper() == "CLEAR")
                {
                    calculator.Clear();
                    Console.Clear();
                    Console.WriteLine("Calculator Cleared");
                    Console.WriteLine("Running Total: " + calculator.getRunningTotal());      //runningTotal --> calc.getRunningTotal()
                    Console.WriteLine("\n" + enterMessage);
                }
                else if (nextEquation.ToUpper() == "EXIT")
                {
                    done = true;
                }
                else if (nextEquation.ToUpper() != "CLEAR" && input.Length != 3)
                {
                    Console.WriteLine("Invalid input. Format as: Num1 [space] Operation [space] Num2");
                }
                else        //Everything followed input format
                {
                    calculator.PassValuesToCalculator(input[0], input[1], input[2]);
                }
            }
        }
    }
}