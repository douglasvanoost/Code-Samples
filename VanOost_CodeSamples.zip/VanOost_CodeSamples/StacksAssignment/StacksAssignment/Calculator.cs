﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StacksAssignment
{
    class Calculator
    {
        private Stack<Memento<double>> m_caretaker = new Stack<Memento<double>>();
        private double m_running_total;

        private double Num1;
        private double Num2;

        private string inputErrorMessage = "Invalid input. Format as 'Num1 [space] Operation [space] Num2";
        
        public Calculator()
        {
            
        }

        public void PassValuesToCalculator(string num1, string operation, string num2)
        {
            bool valid = false;

            if (Double.TryParse(num1, out Num1))
            {
                valid = true;
            }
            else
                Console.WriteLine("Error with first number: " + inputErrorMessage);

            if (Double.TryParse(num2, out Num2))
            {
                valid = true;
            }
            else
                Console.WriteLine("Error with second number: " + inputErrorMessage);

            if (valid)
            {
                string[] operationOptions = new string[4];
                operationOptions[0] = "+";
                operationOptions[1] = "-";
                operationOptions[2] = "*";
                operationOptions[3] = "/";

                bool isOption = false;

                for (int i = 0; i < operationOptions.Length; i++)
                {
                    if (operationOptions[i].CompareTo(operation) == 0)
                    {
                        isOption = true;
                        i = 999;    //make i really big to break loop
                    }
                    else
                        isOption = false;
                }

                if (isOption)       //if input is valid (operation found)
                {
                    Calc_Equals(Num1, operation, Num2);
                }
                else                //if input is not valid (operation not +, -, *, or /)
                    Console.WriteLine("Operation Error. Available options are: +, -, *, or /\n" + inputErrorMessage);
            }
        }
        
        public void Calc_Equals(double Num1, string operation, double Num2)
        {
            string[] operationOptions = new string[4];
            operationOptions[0] = "+";
            operationOptions[1] = "-";
            operationOptions[2] = "*";
            operationOptions[3] = "/";
            
            m_running_total = getRunningTotal();
            double result = 0;

            if (operation == operationOptions[0])
            {
                result = Num1 + Num2;
            }
            else if (operation == operationOptions[1])
            {
                result = Num1 - Num2;
            }
            else if (operation == operationOptions[2])
            {
                result = Num1 * Num2;
            }
            else if (operation == operationOptions[3])
            {
                result = Num1 / Num2;
            }

            //update running total, set a new memento with the new running total, then print them
            m_running_total += result;
            setMemento(m_running_total);
            Print(result, m_running_total);
        }

        public double getRunningTotal()                     //getState()
        {
            if (m_caretaker.Count == 0)
            {
                return 0;
            }
            else
            {
                return Convert.ToDouble(m_caretaker.Peek().Data);
            }
        }

        public void setMemento(double runningTotal)           //setState()
        {
            Memento<double> m = new Memento<double>(runningTotal);
            m_caretaker.Push(m);
        }

        public void Undo()
        {
            if (m_caretaker.Count == 0)
            {
                Console.WriteLine("UNDO Error: Nothing to undo");
            }
            else
            {
                m_caretaker.Pop();
                Console.WriteLine("Running Total: " + getRunningTotal());
            }
        }

        public void Clear()
        {
            m_caretaker = new Stack<Memento<double>>();
        }

        public void Print(double result, double runningTotal)
        {
            Console.WriteLine("Result: " + result +
                               "\nRunning Total: " + runningTotal);
        }
    }
}