﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            //array to fill list
            int[] testerIntArray = { 7, 6, 10, 15, 4, 0, 10, -5, 3, 11, 6, 3, 0, 1, 8 };
            char[] testerCharArray = { 'D', 'o', 'u', 'g', 'l', 'a', 's' };
            string[] testerStringArray = { "Douglas", "douglas", "Brian", "brian" };

            //
            //TESTING INT ARRAY
            //
            OrderedLinkedList<int> testerIntList = new OrderedLinkedList<int>();

            for (int i = 0; i < testerIntArray.Length; i++)
            {
                testerIntList.Add(testerIntArray[i]);
            }

            Console.Write("Before sorting: ");
            for (int i = 0; i < testerIntArray.Length - 1; i++)
            {
                Console.Write(testerIntArray[i].ToString() + ", ");
            }
            Console.WriteLine(testerIntArray[testerIntArray.Length - 1]);
            testerIntList.Print();

            //
            //TESTING CHAR ARRAY
            //
            OrderedLinkedList<Char> testerCharList = new OrderedLinkedList<char>();

            for (int i = 0; i < testerCharArray.Length; i++)
            {
                testerCharList.Add(testerCharArray[i]);
            }

            Console.Write("\nBefore sorting: ");
            for (int i = 0; i < testerCharArray.Length - 1; i++)
            {
                Console.Write(testerCharArray[i].ToString() + ", ");
            }
            Console.WriteLine(testerCharArray[testerCharArray.Length - 1]);
            testerCharList.Print();

            //
            //TESTING STRING ARRAY
            //
            OrderedLinkedList<string> testerStringList = new OrderedLinkedList<string>();

            for (int i = 0; i < testerStringArray.Length; i++)
            {
                testerStringList.Add(testerStringArray[i]);
            }

            Console.Write("\nBefore sorting: ");
            for (int i = 0; i < testerStringArray.Length - 1; i++)
            {
                Console.Write(testerStringArray[i].ToString() + ", ");
            }
            Console.WriteLine(testerStringArray[testerStringArray.Length - 1]);
            testerStringList.Print();
        }
    }
}
