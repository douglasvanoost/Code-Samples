﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedLinkedList
{
    class OrderedLinkedList<E> where E : IComparable
    {
        private LinkedList<E> m_linkedList = new LinkedList<E>();

        public void Add(E element)
        {
            //check to see if the element is the first one being added
            if (m_linkedList.Count == 0)
            {
                m_linkedList.AddFirst(element);
            }

            //smaller than first element
            else if (m_linkedList.First.Value.CompareTo(element) > 0)
            {
                m_linkedList.AddFirst(element);
            }

            //bigger than last element
            else if (m_linkedList.Last.Value.CompareTo(element) < 0)
            {
                m_linkedList.AddLast(element);
            }

            //bigger than first and smaller than last
            else if (m_linkedList.Last.Value.CompareTo(element) > 0 && m_linkedList.First.Value.CompareTo(element) < 0)
            {
                checkNextElement(element);
            }
        }

        //method to loop through the list to find the right spot for the element
        public void checkNextElement(E element)
        {
            foreach (E list_element in m_linkedList)
            {
                int compare = list_element.CompareTo(element);
                LinkedListNode<E> node = m_linkedList.Find(list_element);

                //smaller than or equal to next element
                if (compare > 0)
                {
                    m_linkedList.AddBefore(node, element);
                    break;
                }
            }
        }

        //User friendly print layout
        public void Print()
        {
            E[] array = m_linkedList.ToArray();

            Console.Write("After sorting: ");
            for (int i = 0; i < array.Length - 1; i++)
            {
                Console.Write(array[i].ToString() + ", ");
            }
            Console.WriteLine(array[array.Length - 1]);

        }
    }
}
